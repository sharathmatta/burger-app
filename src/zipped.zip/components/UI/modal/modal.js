import React, { Component } from "react";
import classes from "./modal.module.css";
import Auxiliary from "../../../hoc/Auxiliary";
import Backdrop from "../Backdrop/Backdrop";

class Modal extends Component {
  shouldComponentUpdate(nextProps, prevState) {
    return nextProps.show !== this.props.show;
  }
  render() {
    return (
      <Auxiliary>
        <Backdrop show={this.props.show} clickedBackDrop={this.props.noOrder} />
        <div
          className={classes.Modal}
          style={{
            visibility: this.props.show ? null : "hidden",
            transform: this.props.show ? "translateY(0)" : "translateY(-100vh)",
            opacty: this.props.show ? "1" : "0",
          }}
        >
          {this.props.children}
        </div>
      </Auxiliary>
    );
  }
}

export default Modal;
